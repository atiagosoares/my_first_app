A Pen created at CodePen.io. You can find this one at http://codepen.io/edmundojr/pen/xOYJGw.

 Simple technique to create a dot pattern or dot grid background.

Support: all modern browsers and IE9+